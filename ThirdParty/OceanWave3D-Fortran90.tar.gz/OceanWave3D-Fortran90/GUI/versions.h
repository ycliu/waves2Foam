#ifndef VERSIONS_H
#define VERSIONS_H


#define MATLAB 0
#define externalOutputClass 1



#endif // VERSIONS_H
